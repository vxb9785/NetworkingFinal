/**
 * @mtm9051 on 10/7/2017.
 * -------------------
 */
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Arrays;
import java.util.Iterator;

/**
 * Class coordinates which server is going to be ran
 *
 *      Usage: java Server <serverType<
 */
public class UdpServer {

    private static final String EXIT_CODE = "exit--100";

    public static void main(String[] args) throws Exception {

            new UdpServer();
    }
	
	private UdpServer() throws IOException {
		(new UdpServerThread()).start();
	}
	
	
	public class UdpServerThread extends Thread {

		private final int PORT = 16788;
		private final int BUFFER_SIZE = 256;

		private DatagramSocket socket = null;
		private HashMap<InetAddress, String> clientNames = null;
		private ArrayList<InetAddress> clientAddresses = null;
		private HashMap<InetAddress, Integer> clientPorts = null;


		public UdpServerThread() throws IOException {

			System.out.println("Server::UDP is online at " + InetAddress.getLocalHost());

			socket = new DatagramSocket(PORT);
			clientNames = new HashMap<>();
			clientAddresses = new ArrayList<>();
			clientPorts = new HashMap<>();
		}

		@Override
		public void run() {
			byte buf[] = new byte[BUFFER_SIZE];
			String message;    // preliminary message
            String sendOut;    // what is to be sent out

			while (true) { // closes on ctrl+z
				Arrays.fill(buf, (byte)0);
				try {
					DatagramPacket packet = new DatagramPacket(buf, buf.length);
					socket.receive(packet);    // server waits till it gets something

					String temp = new String(packet.getData());
					message = temp.trim();

					InetAddress fromAddress = packet.getAddress();
					Integer fromPort = packet.getPort();

					// the first message is thhe user's name
					if ( !clientAddresses.contains(fromAddress) ) {

						clientAddresses.add(fromAddress);
						clientPorts.put(fromAddress, fromPort);
						clientNames.put(fromAddress, message); // the client's name

                        sendOut = message + " has entered the chat";
                        System.out.println( sendOut );

					} else {    // if not a new client
						String fromName = clientNames.get(fromAddress);

						if ((message).equals(EXIT_CODE)) {

                            sendOut = fromName + " has left the chat";
                            System.out.println( sendOut );

                            // removing client
                            clientNames.remove(fromAddress);
                            clientPorts.remove(fromAddress);
                            clientAddresses.remove(fromAddress);
                        } else {
                            sendOut = fromName + ": " + message;
                        }
					}

					sendMessage( sendOut );

                } catch (IOException ioe) {
				    System.out.println("IO error encountered"); }
			}
		}


        /**
         * Sends what ever is in member field sendOut
         *
         * @throws IOException
         *       thrown if IO error encountered
         */
		private void sendMessage(String message) throws IOException {

            Iterator<InetAddress> itr = clientAddresses.iterator();

            byte[] data = message.getBytes();
            while (itr.hasNext()) {

                InetAddress clientAddress = itr.next();

                Integer clientPort = clientPorts.get(clientAddress);

                DatagramPacket packet = new DatagramPacket(data, data.length, clientAddress,
                        clientPort);

                socket.send(packet);
            }
        }
	}

}
