/**
 * @mtm9051 on 10/7/2017.
 * -------------------
 */
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Arrays;

/**
 * Class coordinates which server is going to be ran
 *
 *      Usage: java Server <serverType<
 */
public class UdpServer {

    private static final String EXIT_CODE = "exit--100";

    public static void main(String[] args) throws Exception {

            new UdpServer();
    }
	
	public UdpServer() throws IOException {
		(new UdpServerThread()).start();
	}
	
	
	public class UdpServerThread extends Thread {

		private final int PORT = 16788;
		private final int BUFFER_SIZE = 256;

		private DatagramSocket socket = null;
		private DatagramPacket packet = null;
		private HashMap<InetAddress, String> clientNames = null;
		private ArrayList<InetAddress> clientAddresses = null;
		private ArrayList<Integer> clientPorts = null;
		private String sendOut;


		public UdpServerThread() throws IOException {

			System.out.println("Server::UDP is online at " + InetAddress.getLocalHost());

			socket = new DatagramSocket(PORT);
			clientNames = new HashMap<>();
			clientAddresses = new ArrayList<>();
			clientPorts = new ArrayList<>();
		}

		@Override
		public void run() {
			byte buf[] = new byte[BUFFER_SIZE];

			while (true) { // closes on ctrl+z
				Arrays.fill(buf, (byte)0);
				try {
					packet = new DatagramPacket(buf, buf.length);
					socket.receive(packet);    // server waits till it gets something

					String message = new String(buf);
					InetAddress fromAddress = packet.getAddress();
					Integer fromPort = packet.getPort();

					if ( !clientNames.containsKey(fromAddress) ) {
						clientAddresses.add(fromAddress);
						clientPorts.add(fromPort);
						clientNames.put(fromAddress, message); // the client's first

                        sendOut = message + " has entered the chat";
                        System.out.println( sendOut );

                        /*
                           Notify everyone that someone joined
                         */
                        byte[] data = sendOut.getBytes();
                        for (int i = 0; i < clientAddresses.size(); i++) {

                            InetAddress clientAddress = clientAddresses.get(i);
                            Integer clientPort = clientPorts.get(i);
                            packet = new DatagramPacket(data, data.length, clientAddress,
                                    clientPort);
                            socket.send(packet);
                        }
															   // message is their name by design
					} else {
						String fromName = clientNames.get(fromAddress);

						if (message.equals(EXIT_CODE)) {
                            sendOut = message + " has left the chat";
                            System.out.println( sendOut );
                            clientNames.remove(fromAddress);
                            clientAddresses.remove(fromAddress);
                            clientPorts.remove(fromPort);
                        } else
						    sendOut = fromName + ": " + message;
						
						//System.out.println(sendOut);  // for server's visual
						
						byte[] data = sendOut.getBytes();
						for (int i = 0; i < clientAddresses.size(); i++) {

							InetAddress clientAddress = clientAddresses.get(i);
							Integer clientPort = clientPorts.get(i);
							packet = new DatagramPacket(data, data.length, clientAddress,
																		 clientPort);
							socket.send(packet);
						}
					}
				} catch (IOException ioe) { ioe.fillInStackTrace(); }
			}
		}
	}

}
