/**
 * @mtm9051 on 10/7/2017.
 * -------------------
 */
import java.io.IOException;
import java.lang.reflect.Array;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Arrays;
import java.util.Iterator;

/**
 * Class coordinates which server is going to be ran
 *
 *      Usage: java Server <serverType<
 */
public class UdpServer {

    private static final String EXIT_CODE = "exit--100";

    public static void main(String[] args) throws Exception {

    	if (args.length != 1)
    		System.out.println("Usage: java UdpServer <port>");

		new UdpServer(args[0]);
    }

	/**
	 * private constructor
	 *
	 * @throws IOException
     *       thrown if IIO error is encountered
	 */
	private UdpServer(String port) throws IOException {
		(new UdpServerThread(port)).start();
	}


    /**
     *  UdpServerThread class runs the server on another
     *      thread than the main thread
     */
	public class UdpServerThread extends Thread {

		private final int BUFFER_SIZE = 256;

		private DatagramSocket socket = null;
		private HashMap<InetAddress, ArrayList<String>> clientNames = null;
        // client ip to list of ports ( for +1 users on a comp)
		private HashMap<InetAddress, ArrayList<Integer>> clientConn = null;


		public UdpServerThread(String p) throws IOException {

			System.out.println("Server::UDP is online at " + InetAddress.getLocalHost());

			int port = 0;
			try {
				port = Integer.parseInt(p);
			} catch (NumberFormatException n) {
				System.out.println("Invalid port");
			}

			socket = new DatagramSocket(port);
			clientNames = new HashMap<>();
			//clientAddresses = new ArrayList<>();
            clientConn = new HashMap<>();
		}

		@Override
		public void run() {
			byte buf[] = new byte[BUFFER_SIZE];
			String message;    // preliminary message
            String sendOut;    // what is to be sent out

			while (true) { // closes on ctrl+z
				Arrays.fill(buf, (byte)0);
				try {
					DatagramPacket packet = new DatagramPacket(buf, buf.length);
					socket.receive(packet);    // server waits till it gets something

					String temp = new String(packet.getData());
					message = temp.trim();

					InetAddress fromAddress = packet.getAddress();
					Integer fromPort = packet.getPort();

					// the first message is thhe user's name
					if ( ! (clientConn.containsKey(fromAddress) &&
                            clientConn.get(fromAddress).contains(fromPort))) {

						this.addClient(fromAddress, fromPort, message);

                        sendOut = message + " has entered the chat";
                        System.out.println( sendOut );

					} else {    // if not a new client

                        int index = clientConn.get(fromAddress).indexOf(fromPort);
						String fromName = clientNames.get(fromAddress).get(index);

						if ((message).equals(EXIT_CODE)) {

                            sendOut = fromName + " has left the chat";
                            System.out.println( sendOut );

                            this.removeClient(fromAddress, index);

                        } else {
                            sendOut = fromName + ": " + message;
                        }
					}

					sendMessage( sendOut );

                } catch (IOException ioe) {
				    System.out.println("IO error encountered"); }
			}
		}


        /**
         * Sends what ever is in member field sendOut
         *
         * @throws IOException
         *       thrown if IO error encountered
         */
		private void sendMessage(String message) throws IOException {

            byte[] data = message.getBytes();

            for ( InetAddress clientAddress : clientConn.keySet() ) {

                ArrayList<Integer> ports = clientConn.get(clientAddress);

                for (Integer port : ports) {

                    DatagramPacket packet = new DatagramPacket(data, data.length,
                            clientAddress, port);

                    socket.send(packet);
                }
            }
        }


        /**
         * Adds a client to the maps, if he is not a registered client
         *
         * @param fromAddress the client's address
         * @param fromPort the client's port
         * @param name the client's screenname
         */
        private void addClient(InetAddress fromAddress, Integer fromPort, String name) {

            ArrayList<Integer> ports;
            if ( !clientConn.containsKey(fromAddress)) {
                ports = new ArrayList<>();
                ports.add(fromPort);
            } else {
                ports = clientConn.get(fromAddress);
                ports.add(fromPort);
            }
            clientConn.put(fromAddress, ports);

            
            ArrayList<String> names;
            if ( ! clientNames.containsKey(fromAddress)) {
                names = new ArrayList<>();
                names.add(name);
            } else {
                names = clientNames.get(fromAddress);
                names.add(name);
            }
            clientNames.put(fromAddress, names); // the client's name

        }


        /**
         * Removes a client from the maps, if he is not a registered client
         *
         * @param fromAddress the client's address
         * @param index of client in the arrayLists
         */
        private void removeClient(InetAddress fromAddress, int index) {

            // removing client
            ArrayList<Integer> ports = clientConn.get(fromAddress);

            ports.remove(index);
            clientNames.get(fromAddress).remove(index);

            if (ports.isEmpty()) {
                clientConn.remove(fromAddress);
                clientNames.remove(fromAddress);
            }
        }
	}

}
