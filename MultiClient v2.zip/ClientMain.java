/**
 * Created by Matt Maloney on 11/16/2017
 * matttm : mtm9051
 * matttmaloney@gmail.com
 * mtm9051@rit.edu
 * Language:  Java 1.8
 */

import javax.swing.*;

/**
 *  ClientMain class is a starts a screen to select whether the TCP or UDP
 *    Client is invoked
 */
public class ClientMain {

    /**
     * empty constructor
     */
    private ClientMain() {}


    public static void main(String[] args) {

        if (args.length!=0) {
            System.out.println("No arguments required");
            //System.exit(0);
        }

        String clientTypes[] = {"TCP", "UDP"};

        int response = JOptionPane.showOptionDialog(null,
                "Select the desired protocol to connect to server",
                "Protocol", JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE,
                null,clientTypes, clientTypes[0] );

        if (response == 0)
            TcpClient.main(args);
        else if (response == 1)
            UdpClient.main(args);

    }
}
